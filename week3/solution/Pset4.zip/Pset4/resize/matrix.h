#include <stdint.h>

struct matrix{
    int columns[];
    int rows[];
};
